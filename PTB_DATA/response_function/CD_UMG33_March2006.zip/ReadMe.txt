*************************************************
***      Welcome  to   U_M_G   vers. 3.3      ***
***      Unfolding with Maxed and Gravel      ***
*************************************************

File:            ReadMe.txt
Release date:    01 - March - 2006

====================================================================================

The complete package needs about 80 MBytes on the computer hard disk.

Please follow these steps to install the "UMG 3.3" package on your computer:

====================================================================================


*** Windows 95/98/ME: **************************************************************

1.  Change to folder "Win_9xMe" on your UMG33 CD

2.  Double-klick on the "UMG_9xME.exe" in this folder

3.  Press the "OK" button of the "UMG Welcome window"

4.  Press the "Setup" button in the window "WinZip Selp-Extractor - UMG33_9xME.exe;
    all files are unzipped to a folder WZSE*.TMP in your "TEMP" folder.

5.  A new DOS-box opens, please follow the instructions 

6a. If you find the following message after everything was copied:
      ** Some UMG icons could not be copied to your DESKTOP
         Please copy the appropriate icons
         - UMG-xC$i (x = M or F; i= c,d or e)
         - UMGPlo$i (i= c,d or e)
         from the directory %1\U_M_G to your DESKTOP
    then:
      please follow these instructions for

      - Few-Channel unfolding:   
        if you installed UMG to drive C: then 
          rename UMG-FC$c(.pif) to UMG-FC(.pif)
          rename UMGPlo$c(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive D: then 
          rename UMG-FC$d(.pif) to UMG-FC(.pif)
          rename UMGPlo$d(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive E: then 
          rename UMG-FC$e(.pif) to UMG-FC(.pif)
          rename UMGPlo$e(.lnk) to UMGPlot(.lnk)

      - Multi-Channel unfolding:
        if you installed UMG to drive C: then 
          rename UMG-MC$c(.pif) to UMG-MC(.pif)
          rename UMGPlo$c(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive D: then 
          rename UMG-MC$d(.pif) to UMG-MC(.pif)
          rename UMGPlo$d(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive E: then rename 
          rename UMG-MC$e(.pif) to UMG-MC(.pif)
          rename UMGPlo$e(.lnk) to UMGPlot(.lnk)

      and finally copy this file to your "Desktop".


6b. If you do not find the UMG icons on your current desktop
    then the icons were copied to folder C:\Windows\Desktop which is not your 
    personal desktop (since there are profiles stored for several users on the PC).
    Copy the icons UMG_FC(.pif) and/or UMG_MC(.pif) and UMGPlot(.lnk) 
    to your current desktop.

7.  DONE !!!



*** Windows NT/2000/XP: ************************************************************

1.  Change to folder "Win_NTXP" on your UMG33 CD

2.  Double-klick on the "UMG_NTXP.exe" in this folder

3.  Press the "OK" button of the "UMG Welcome window"

4.  Press the "Setup" button in the window "WinZip Selp-Extractor - UMG32_NTXP.exe;
    all files are unzipped to a folder WZSE*.TMP in your "TEMP" folder.

5.  A new DOS-box opens, please follow the instructions 

6.  Most probably you will find the following message after everything was copied:
      ** Some UMG icons could not be copied to your DESKTOP
         Please copy the appropriate icons
         - UMG-xC$i (x = M or F; i= c,d or e)
         - UMGPlo$i (i= c,d or e)
         from the directory %1\U_M_G to your DESKTOP

    In this case please follow these instructions for

    - Few-Channel unfolding:   
        if you installed UMG to drive C: then 
          rename UMG-FC$c(.pif) to UMG-FC(.pif)
          rename UMGPlo$c(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive D: then 
          rename UMG-FC$d(.pif) to UMG-FC(.pif)
          rename UMGPlo$d(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive E: then 
          rename UMG-FC$e(.pif) to UMG-FC(.pif)
          rename UMGPlo$e(.lnk) to UMGPlot(.lnk)

      - Multi-Channel unfolding:
        if you installed UMG to drive C: then 
          rename UMG-MC$c(.pif) to UMG-MC(.pif)
          rename UMGPlo$c(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive D: then 
          rename UMG-MC$d(.pif) to UMG-MC(.pif)
          rename UMGPlo$d(.lnk) to UMGPlot(.lnk)
        if you installed UMG to drive E: then rename 
          rename UMG-MC$e(.pif) to UMG-MC(.pif)
          rename UMGPlo$e(.lnk) to UMGPlot(.lnk)

    and copy this file to your "Desktop".


7.  DONE !!!


*** Other operating systems (Linux, etc.)                ****************************
    and non-automatic installation for Windows platforms ****************************

>>> This directory contains a one-to-one copy of the UMG package as it will be 
    installed on your harddrive. 
    With the exeption of the "$bin" directories all files are ASCII files.

1.  At this stage there is no other platforms than Windows available at PTB 
    on which we could develop the UMG package. 

2.  Change to folder "Y_general" (other operating systems).

3.  The easiest way of installation is to copy the complete folder "U_M_G" 
    (the one and only folder of the UMG package) to a harddisk of your choice.

4.  Change to your selected harddisk and to folder "U_M_G":

5.  Other OS: continue with step 7.

5a. Windows OS: change to folder "$tools\UMGPlot"
    
5b. To register program UMGPlot, once
    - Windows95/98/Me:   execute batch file "Reg98.bat" 
    - WindowsNT/2000/XP: execute batch file "RegXP.bat" 
    After the registration, the file UMGPlot.exe MUST NOT be moved to another location

5c. See file "DirStruc.txt" for further directory structure.

6.  DONE !!!


7a. Other OS: delete folder "$tools".

7b. Delete all files in directory "FC\$bin" and "MC\$bin".
 
8.  Change to folder "FC\$inp\src_code" and/or "FC\$inp\src_code" and 
    compile (FORTRAN90) and link programs GRC_#C, MXD_#C and IQU_#C.

9.  DONE !!!
