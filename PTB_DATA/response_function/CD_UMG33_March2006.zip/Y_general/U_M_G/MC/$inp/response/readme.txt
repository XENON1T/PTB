-Response matrix without gaussian broadening:
 ddg025cm.asc
-Response matrix with best parameter for
 gaussian broadening:
 ddg025cm.rsp
-Parameter for gaussian broadening multiplied 
 with 0.8:
 ddg025-2.rsp
-Parameter for gaussian broadening multiplied 
 with 1.2:
 ddg025-3.rsp